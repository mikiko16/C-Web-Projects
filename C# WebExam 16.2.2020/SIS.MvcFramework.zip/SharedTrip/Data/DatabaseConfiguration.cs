﻿namespace SharedTrip
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-5BOK8LI\MSSQLSERVER01;Database=SharedTrip;Trusted_Connection=True;Integrated Security=True;";
    }
}