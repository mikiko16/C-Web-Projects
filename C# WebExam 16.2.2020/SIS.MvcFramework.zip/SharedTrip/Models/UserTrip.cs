﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SharedTrip.Models
{
    public class UserTrip
    {
        public string USerId { get; set; }

        public User User { get; set; }

        public Trip Trip { get; set; }

        public string TripId { get; set; }
    }
}
